// SR SOLUTION — shared front-end behavior (demo, no backend wired up)

document.addEventListener('DOMContentLoaded', () => {

  /* Mobile nav toggle */
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  /* Breaker panel: randomly flip a couple of switches on load for life */
  document.querySelectorAll('.breaker').forEach((b, i) => {
    setTimeout(() => {
      if (Math.random() > 0.4) b.classList.add('on');
    }, 300 + i * 120);
  });

  /* Auth form tabs (login.html / register.html) */
  document.querySelectorAll('.form-tabs').forEach(tabs => {
    const buttons = tabs.querySelectorAll('button');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.getAttribute('data-target');
        document.querySelectorAll('.form-panel').forEach(p => {
          p.style.display = (p.id === target) ? 'block' : 'none';
        });
      });
    });
  });

  /* Generic demo-submit intercept: prevent real submission, show inline note */
  document.querySelectorAll('form[data-demo]').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let note = form.querySelector('.demo-note');
      if (!note) {
        note = document.createElement('p');
        note.className = 'demo-note';
        note.style.cssText = 'margin-top:14px;font-size:12.5px;color:#16A34A;font-family:var(--mono);text-align:center;';
        form.appendChild(note);
      }
      note.textContent = '✓ Demo form — wire this up to your PHP backend to go live.';
    });
  });

  /* ---------------- Booking flow (booking.html) ---------------- */
  const bookingRoot = document.querySelector('.booking-shell');
  if (bookingRoot) {
    const steps = Array.from(bookingRoot.querySelectorAll('.booking-step'));
    const railPts = Array.from(document.querySelectorAll('.progress-rail .pt'));
    let current = 0;

    const selections = {
      service: null,
      priceLabel: '—',
      date: null,
      time: null,
      address: ''
    };

    function renderSummary() {
      const sv = document.getElementById('sum-service');
      const dt = document.getElementById('sum-datetime');
      const ad = document.getElementById('sum-address');
      const tot = document.getElementById('sum-total');
      if (sv) sv.textContent = selections.service || 'Not selected';
      if (dt) dt.textContent = (selections.date && selections.time) ? `${selections.date}, ${selections.time}` : 'Not selected';
      if (ad) ad.textContent = selections.address || 'Not entered';
      if (tot) tot.textContent = selections.priceLabel;
    }

    function goTo(idx) {
      steps.forEach((s, i) => s.classList.toggle('active', i === idx));
      railPts.forEach((p, i) => {
        p.classList.toggle('done', i < idx);
        p.classList.toggle('active', i === idx);
      });
      current = idx;
      window.scrollTo({ top: bookingRoot.offsetTop - 110, behavior: 'smooth' });
    }

    bookingRoot.querySelectorAll('[data-next]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (current < steps.length - 1) goTo(current + 1);
      });
    });
    bookingRoot.querySelectorAll('[data-back]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (current > 0) goTo(current - 1);
      });
    });

    bookingRoot.querySelectorAll('.option-card[data-service]').forEach(card => {
      card.addEventListener('click', () => {
        bookingRoot.querySelectorAll('.option-card[data-service]').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        selections.service = card.getAttribute('data-service');
        selections.priceLabel = card.getAttribute('data-price') || '—';
        renderSummary();
      });
    });

    bookingRoot.querySelectorAll('.option-card[data-time]').forEach(card => {
      card.addEventListener('click', () => {
        bookingRoot.querySelectorAll('.option-card[data-time]').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        selections.time = card.getAttribute('data-time');
        renderSummary();
      });
    });

    const dateInput = document.getElementById('booking-date');
    if (dateInput) {
      dateInput.addEventListener('change', () => {
        selections.date = dateInput.value;
        renderSummary();
      });
    }
    const addrInput = document.getElementById('booking-address');
    if (addrInput) {
      addrInput.addEventListener('input', () => {
        selections.address = addrInput.value;
        renderSummary();
      });
    }

    const confirmBtn = document.getElementById('confirm-booking');
    if (confirmBtn) {
      confirmBtn.addEventListener('click', () => {
        goTo(steps.length - 1);
        const code = document.getElementById('booking-code');
        if (code) code.textContent = 'SR-' + Math.floor(100000 + Math.random() * 900000);
      });
    }

    renderSummary();
  }

});
